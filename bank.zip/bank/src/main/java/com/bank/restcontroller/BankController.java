package com.bank.restcontroller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bank.model.Credential;
import com.bank.model.ResponseDTO;
import com.bank.model.User;
import com.bank.service.BankService;

import jakarta.validation.Valid;

@RestController
public class BankController {
	@Autowired
	private BankService bankService;
	@GetMapping("/home")
	public String home() {
		return "welcome";
		}
	@PostMapping("/signUp")
	public String createNewUser(@Valid @RequestBody User user) {
		
		User newUser = bankService.createUser(user);
		System.out.println("user is created");
		return newUser.getUserName();
	}
	
	@GetMapping("/findUser")
	public String checkUserPresent(@RequestBody Credential Credential) {
		User user = bankService.findUser(Credential);
		
		if(null!=user.getUserName()) {
			System.out.println(user.getName());
			return "user is found";
		}else
		{
			home();
		}
		return null;
		
	}
	@GetMapping("/login")
	public ResponseEntity<ResponseDTO> getUser(@RequestBody Credential Credential){
		ResponseDTO responseDTO=new ResponseDTO();
		String userName = Credential.getUserName();
		User user = bankService.findUserByUserName(userName);
		if(user==null) {
			responseDTO.setMessage("user not found");
			return new ResponseEntity<>(responseDTO,HttpStatus.NOT_FOUND);
		}
		else
		{
			responseDTO.setMessage("user is found");
			return new ResponseEntity<>(responseDTO,HttpStatus.OK);
		}
		
		
	}

}
