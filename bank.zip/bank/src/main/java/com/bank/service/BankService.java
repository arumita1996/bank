package com.bank.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.dao.impl.BankdaoImpl;
import com.bank.model.Credential;
import com.bank.model.User;

@Service
public interface BankService {
	
	public User createUser(User user);
		
	public User findUser(Credential Credential);
	
	public User findUserByUserName(String userName);

}
