package com.bank.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bank.dao.impl.BankdaoImpl;
import com.bank.model.Credential;
import com.bank.model.User;
import com.bank.service.BankService;

@Component
public class BankServiceImpl implements BankService{
	@Autowired
	private BankdaoImpl bankDaoImpl;
	
	@Override
	public User createUser(User user) {
		int len=user.getDob().length();
		int start=len-4;
		String dob = user.getDob().substring((start),(len));
		String name = user.getName();
		String userName=(name+dob);
		user.setUserName(userName);
		bankDaoImpl.saveUser(user);
		return user;
	}

	@Override
	public User findUser(Credential Credential) {
		User user = bankDaoImpl.checkUser(Credential);
		return user;
	}

	@Override
	public User findUserByUserName(String userName) {
		User user = bankDaoImpl.FindUserByUserName(userName);
		return user;
	}
		

}
