package com.bank.dao.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bank.dao.BankRepo;
import com.bank.model.Credential;
import com.bank.model.User;

@Component
public class BankdaoImpl {
	@Autowired
	private BankRepo bankRepo;
	
	public User saveUser(User user) {
		bankRepo.save(user);
		return user;
	}
	
	public User checkUser(Credential Credential)
	{
		
		 User user = bankRepo.findById(Credential.getId()).get();
		 return user;
		
	}
	
	public User FindUserByUserName(String userName) {
		User user = bankRepo.findByUserName(userName);
		return user;
	}

}
